using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class AlertaRisco
    {
        public int IdAlerta { get; set; }
        public int IdMatricula { get; set; }
        public string? TipoRisco { get; set; }
        public decimal Score { get; set; }
        public string? Status { get; set; }
        public Matricula? Matricula { get; set; }

        public AlertaRisco()
        {
            IdAlerta = 0;
            Status = "pendente";
        }

        public AlertaRisco(int idAlerta)
        {
            IdAlerta = idAlerta;
        }

        public AlertaRisco(int idAlerta, int idMatricula, string? tipoRisco, decimal score, string? status)
        {
            IdAlerta = idAlerta;
            IdMatricula = idMatricula;
            TipoRisco = tipoRisco;
            Score = score;
            Status = status;
        }

        public AlertaRisco(int idMatricula, string? tipoRisco, decimal score, string? status)
        {
            IdMatricula = idMatricula;
            TipoRisco = tipoRisco;
            Score = score;
            Status = status;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into alerta_risco (id_matricula, tipo_risco, score, status)
                    values (@id_matricula, @tipo_risco, @score, @status);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
                cmd.Parameters.AddWithValue("@tipo_risco", TipoRisco);
                cmd.Parameters.AddWithValue("@score", Score);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "pendente" : Status);

                IdAlerta = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdAlerta > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdAlerta < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update alerta_risco
                    set id_matricula = @id_matricula,
                        tipo_risco = @tipo_risco,
                        score = @score,
                        status = @status
                    where id_alerta = @id_alerta";

                cmd.Parameters.AddWithValue("@id_alerta", IdAlerta);
                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
                cmd.Parameters.AddWithValue("@tipo_risco", TipoRisco);
                cmd.Parameters.AddWithValue("@score", Score);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "pendente" : Status);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdAlerta < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from alerta_risco where id_alerta = @id_alerta";
                cmd.Parameters.AddWithValue("@id_alerta", IdAlerta);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static AlertaRisco ObterPorId(int idAlerta)
        {
            AlertaRisco alerta = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_alerta, id_matricula, tipo_risco, score, status
                    from alerta_risco
                    where id_alerta = @id_alerta";
                cmd.Parameters.AddWithValue("@id_alerta", idAlerta);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    alerta = MontarAlerta(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return alerta;
        }

        public static List<AlertaRisco> ObterLista(string busca = "")
        {
            List<AlertaRisco> alertas = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_alerta, id_matricula, tipo_risco, score, status
                    from alerta_risco
                    where tipo_risco like @busca or status like @busca
                    order by id_alerta desc";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    alertas.Add(MontarAlerta(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return alertas;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select ar.*, u.nome as aluno
                    from alerta_risco ar
                    inner join matriculas m on m.id_matricula = ar.id_matricula
                    inner join alunos a on a.id_aluno = m.id_aluno
                    inner join usuarios u on u.id_usuario = a.id_usuario
                    order by ar.id_alerta desc";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        private static AlertaRisco MontarAlerta(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetString(2),
                dr.GetDecimal(3),
                dr.GetString(4)
            );
        }
    }
}
