using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Curso
    {
        public int IdCurso { get; set; }
        public string? Nome { get; set; }
        public string? Descricao { get; set; }
        public int CargaHoraria { get; set; }
        public string? Status { get; set; }

        public Curso()
        {
            IdCurso = 0;
            Status = "ativo";
        }

        public Curso(int idCurso)
        {
            IdCurso = idCurso;
        }

        public Curso(int idCurso, string? nome, string? descricao, int cargaHoraria, string? status)
        {
            IdCurso = idCurso;
            Nome = nome;
            Descricao = descricao;
            CargaHoraria = cargaHoraria;
            Status = status;
        }

        public Curso(string? nome, string? descricao, int cargaHoraria, string? status)
        {
            Nome = nome;
            Descricao = descricao;
            CargaHoraria = cargaHoraria;
            Status = status;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into cursos (nome, descricao, carga_horaria, status)
                    values (@nome, @descricao, @carga_horaria, @status);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@descricao", string.IsNullOrEmpty(Descricao) ? DBNull.Value : Descricao);
                cmd.Parameters.AddWithValue("@carga_horaria", CargaHoraria);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativo" : Status);

                IdCurso = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdCurso > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdCurso < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update cursos
                    set nome = @nome,
                        descricao = @descricao,
                        carga_horaria = @carga_horaria,
                        status = @status
                    where id_curso = @id_curso";

                cmd.Parameters.AddWithValue("@id_curso", IdCurso);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@descricao", string.IsNullOrEmpty(Descricao) ? DBNull.Value : Descricao);
                cmd.Parameters.AddWithValue("@carga_horaria", CargaHoraria);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativo" : Status);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdCurso < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from cursos where id_curso = @id_curso";
                cmd.Parameters.AddWithValue("@id_curso", IdCurso);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Curso ObterPorId(int idCurso)
        {
            Curso curso = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_curso, nome, descricao, carga_horaria, status
                    from cursos
                    where id_curso = @id_curso";
                cmd.Parameters.AddWithValue("@id_curso", idCurso);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    curso = MontarCurso(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return curso;
        }

        public static List<Curso> ObterLista(string busca = "")
        {
            List<Curso> cursos = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_curso, nome, descricao, carga_horaria, status
                    from cursos
                    where nome like @busca or status like @busca
                    order by nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    cursos.Add(MontarCurso(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return cursos;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from cursos order by nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        private static Curso MontarCurso(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetString(1),
                dr.IsDBNull(2) ? null : dr.GetString(2),
                dr.GetInt32(3),
                dr.GetString(4)
            );
        }
    }
}
