using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Disciplina
    {
        public int IdDisciplina { get; set; }
        public int IdCurso { get; set; }
        public string? Nome { get; set; }
        public int CargaHoraria { get; set; }
        public Curso? Curso { get; set; }

        public Disciplina()
        {
            IdDisciplina = 0;
        }

        public Disciplina(int idDisciplina)
        {
            IdDisciplina = idDisciplina;
        }

        public Disciplina(int idDisciplina, int idCurso, string? nome, int cargaHoraria)
        {
            IdDisciplina = idDisciplina;
            IdCurso = idCurso;
            Nome = nome;
            CargaHoraria = cargaHoraria;
        }

        public Disciplina(int idCurso, string? nome, int cargaHoraria)
        {
            IdCurso = idCurso;
            Nome = nome;
            CargaHoraria = cargaHoraria;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into disciplinas (id_curso, nome, carga_horaria)
                    values (@id_curso, @nome, @carga_horaria);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_curso", IdCurso);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@carga_horaria", CargaHoraria);

                IdDisciplina = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdDisciplina > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdDisciplina < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update disciplinas
                    set id_curso = @id_curso,
                        nome = @nome,
                        carga_horaria = @carga_horaria
                    where id_disciplina = @id_disciplina";

                cmd.Parameters.AddWithValue("@id_disciplina", IdDisciplina);
                cmd.Parameters.AddWithValue("@id_curso", IdCurso);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@carga_horaria", CargaHoraria);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdDisciplina < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from disciplinas where id_disciplina = @id_disciplina";
                cmd.Parameters.AddWithValue("@id_disciplina", IdDisciplina);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Disciplina ObterPorId(int idDisciplina)
        {
            Disciplina disciplina = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_disciplina, id_curso, nome, carga_horaria
                    from disciplinas
                    where id_disciplina = @id_disciplina";
                cmd.Parameters.AddWithValue("@id_disciplina", idDisciplina);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    disciplina = MontarDisciplina(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return disciplina;
        }

        public static List<Disciplina> ObterLista(string busca = "")
        {
            List<Disciplina> disciplinas = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select d.id_disciplina, d.id_curso, d.nome, d.carga_horaria
                    from disciplinas d
                    inner join cursos c on c.id_curso = d.id_curso
                    where d.nome like @busca or c.nome like @busca
                    order by d.nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    disciplinas.Add(MontarDisciplina(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return disciplinas;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select d.*, c.nome as curso
                    from disciplinas d
                    inner join cursos c on c.id_curso = d.id_curso
                    order by d.nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        private static Disciplina MontarDisciplina(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetString(2),
                dr.GetInt32(3)
            );
        }
    }
}
