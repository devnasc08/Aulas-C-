using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Frequencia
    {
        public int IdFrequencia { get; set; }
        public int IdMatricula { get; set; }
        public int IdDisciplina { get; set; }
        public int TotalAulas { get; set; }
        public int Presencas { get; set; }
        public decimal Percentual { get; set; }

        public Frequencia()
        {
            IdFrequencia = 0;
        }

        public Frequencia(int idFrequencia)
        {
            IdFrequencia = idFrequencia;
        }

        public Frequencia(int idFrequencia, int idMatricula, int idDisciplina, int totalAulas, int presencas, decimal percentual)
        {
            IdFrequencia = idFrequencia;
            IdMatricula = idMatricula;
            IdDisciplina = idDisciplina;
            TotalAulas = totalAulas;
            Presencas = presencas;
            Percentual = percentual;
        }

        public Frequencia(int idMatricula, int idDisciplina, int totalAulas, int presencas)
        {
            IdMatricula = idMatricula;
            IdDisciplina = idDisciplina;
            TotalAulas = totalAulas;
            Presencas = presencas;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into frequencia (id_matricula, id_disciplina, total_aulas, presencas)
                    values (@id_matricula, @id_disciplina, @total_aulas, @presencas)
                    on duplicate key update
                        total_aulas = @total_aulas,
                        presencas = @presencas;
                    select id_frequencia from frequencia where id_matricula = @id_matricula and id_disciplina = @id_disciplina;";

                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
                cmd.Parameters.AddWithValue("@id_disciplina", IdDisciplina);
                cmd.Parameters.AddWithValue("@total_aulas", TotalAulas);
                cmd.Parameters.AddWithValue("@presencas", Presencas);

                IdFrequencia = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdFrequencia > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdFrequencia < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update frequencia
                    set id_matricula = @id_matricula,
                        id_disciplina = @id_disciplina,
                        total_aulas = @total_aulas,
                        presencas = @presencas
                    where id_frequencia = @id_frequencia";

                cmd.Parameters.AddWithValue("@id_frequencia", IdFrequencia);
                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
                cmd.Parameters.AddWithValue("@id_disciplina", IdDisciplina);
                cmd.Parameters.AddWithValue("@total_aulas", TotalAulas);
                cmd.Parameters.AddWithValue("@presencas", Presencas);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdFrequencia < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from frequencia where id_frequencia = @id_frequencia";
                cmd.Parameters.AddWithValue("@id_frequencia", IdFrequencia);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Frequencia ObterPorId(int idFrequencia)
        {
            Frequencia frequencia = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_frequencia, id_matricula, id_disciplina, total_aulas, presencas, percentual
                    from frequencia
                    where id_frequencia = @id_frequencia";
                cmd.Parameters.AddWithValue("@id_frequencia", idFrequencia);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    frequencia = MontarFrequencia(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return frequencia;
        }

        public static List<Frequencia> ObterLista(string busca = "")
        {
            List<Frequencia> frequencias = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select f.id_frequencia, f.id_matricula, f.id_disciplina, f.total_aulas, f.presencas, f.percentual
                    from frequencia f
                    inner join disciplinas d on d.id_disciplina = f.id_disciplina
                    where d.nome like @busca
                    order by d.nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    frequencias.Add(MontarFrequencia(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return frequencias;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select f.*, d.nome as disciplina
                    from frequencia f
                    inner join disciplinas d on d.id_disciplina = f.id_disciplina
                    order by d.nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public void CalcularPercentual()
        {
            if (TotalAulas > 0)
                Percentual = (Presencas * 100m) / TotalAulas;
            else
                Percentual = 0;
        }

        private static Frequencia MontarFrequencia(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetInt32(2),
                dr.GetInt32(3),
                dr.GetInt32(4),
                dr.IsDBNull(5) ? 0 : dr.GetDecimal(5)
            );
        }
    }
}
