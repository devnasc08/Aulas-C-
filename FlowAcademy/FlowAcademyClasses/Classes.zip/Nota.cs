using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Nota
    {
        public int IdNota { get; set; }
        public int IdMatricula { get; set; }
        public int IdDisciplina { get; set; }
        public decimal? Prova1 { get; set; }
        public decimal? Prova2 { get; set; }
        public decimal? Trabalho { get; set; }
        public decimal? Comportamental { get; set; }
        public decimal? MediaUc { get; set; }
        public string? Status { get; set; }
        public DateTime DataLancamento { get; set; }

        public decimal Nota1
        {
            get { return Prova1 ?? 0; }
            set { Prova1 = value; }
        }

        public decimal Nota2
        {
            get { return Prova2 ?? 0; }
            set { Prova2 = value; }
        }

        public decimal MediaFinal
        {
            get { return MediaUc ?? 0; }
            set { MediaUc = value; }
        }

        public Nota()
        {
            IdNota = 0;
            Status = "em_andamento";
            DataLancamento = DateTime.Now;
        }

        public Nota(int idNota)
        {
            IdNota = idNota;
        }

        public Nota(int idNota, int idMatricula, int idDisciplina, decimal? prova1, decimal? prova2, decimal? trabalho, decimal? comportamental, decimal? mediaUc, string? status, DateTime dataLancamento)
        {
            IdNota = idNota;
            IdMatricula = idMatricula;
            IdDisciplina = idDisciplina;
            Prova1 = prova1;
            Prova2 = prova2;
            Trabalho = trabalho;
            Comportamental = comportamental;
            MediaUc = mediaUc;
            Status = status;
            DataLancamento = dataLancamento;
        }

        public bool Inserir()
        {
            bool inserido = false;
            CalcularMedia();
            VerificarStatus();

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into notas (id_matricula, id_disciplina, prova_1, prova_2, trabalho, comportamental, media_uc, status, data_lancamento)
                    values (@id_matricula, @id_disciplina, @prova_1, @prova_2, @trabalho, @comportamental, @media_uc, @status, now())
                    on duplicate key update
                        prova_1 = @prova_1,
                        prova_2 = @prova_2,
                        trabalho = @trabalho,
                        comportamental = @comportamental,
                        media_uc = @media_uc,
                        status = @status,
                        data_lancamento = now();
                    select id_nota from notas where id_matricula = @id_matricula and id_disciplina = @id_disciplina;";

                AdicionarParametros(cmd);

                IdNota = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdNota > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdNota < 1) return atualizado;

            CalcularMedia();
            VerificarStatus();

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update notas
                    set id_matricula = @id_matricula,
                        id_disciplina = @id_disciplina,
                        prova_1 = @prova_1,
                        prova_2 = @prova_2,
                        trabalho = @trabalho,
                        comportamental = @comportamental,
                        media_uc = @media_uc,
                        status = @status,
                        data_lancamento = now()
                    where id_nota = @id_nota";

                cmd.Parameters.AddWithValue("@id_nota", IdNota);
                AdicionarParametros(cmd);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdNota < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from notas where id_nota = @id_nota";
                cmd.Parameters.AddWithValue("@id_nota", IdNota);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Nota ObterPorId(int idNota)
        {
            Nota nota = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_nota, id_matricula, id_disciplina, prova_1, prova_2, trabalho, comportamental, media_uc, status, data_lancamento
                    from notas
                    where id_nota = @id_nota";
                cmd.Parameters.AddWithValue("@id_nota", idNota);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    nota = MontarNota(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return nota;
        }

        public static List<Nota> ObterLista(string busca = "")
        {
            List<Nota> notas = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select n.id_nota, n.id_matricula, n.id_disciplina, n.prova_1, n.prova_2, n.trabalho, n.comportamental, n.media_uc, n.status, n.data_lancamento
                    from notas n
                    inner join disciplinas d on d.id_disciplina = n.id_disciplina
                    where d.nome like @busca or n.status like @busca
                    order by n.data_lancamento desc";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    notas.Add(MontarNota(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return notas;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select n.*, d.nome as disciplina
                    from notas n
                    inner join disciplinas d on d.id_disciplina = n.id_disciplina
                    order by n.data_lancamento desc";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public void CalcularMedia()
        {
            if (Prova1.HasValue && Prova2.HasValue && Trabalho.HasValue && Comportamental.HasValue)
                MediaUc = (Prova1.Value * 0.30m) + (Prova2.Value * 0.30m) + (Trabalho.Value * 0.30m) + (Comportamental.Value * 0.10m);
        }

        public void VerificarStatus()
        {
            if (!MediaUc.HasValue)
                Status = "em_andamento";
            else if (MediaUc.Value >= 6.0m)
                Status = "aprovado";
            else
                Status = "reprovado";
        }

        private void AdicionarParametros(MySqlCommand cmd)
        {
            cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
            cmd.Parameters.AddWithValue("@id_disciplina", IdDisciplina);
            cmd.Parameters.AddWithValue("@prova_1", Prova1.HasValue ? Prova1.Value : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@prova_2", Prova2.HasValue ? Prova2.Value : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@trabalho", Trabalho.HasValue ? Trabalho.Value : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@comportamental", Comportamental.HasValue ? Comportamental.Value : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@media_uc", MediaUc.HasValue ? MediaUc.Value : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "em_andamento" : Status);
        }

        private static Nota MontarNota(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetInt32(2),
                dr.IsDBNull(3) ? null : dr.GetDecimal(3),
                dr.IsDBNull(4) ? null : dr.GetDecimal(4),
                dr.IsDBNull(5) ? null : dr.GetDecimal(5),
                dr.IsDBNull(6) ? null : dr.GetDecimal(6),
                dr.IsDBNull(7) ? null : dr.GetDecimal(7),
                dr.GetString(8),
                dr.GetDateTime(9)
            );
        }
    }
}
