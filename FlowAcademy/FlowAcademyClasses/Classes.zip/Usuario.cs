using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string? Nome { get; set; }
        public string? Email { get; set; }
        public string? SenhaHash { get; set; }
        public string? Senha
        {
            get { return SenhaHash; }
            set { SenhaHash = value; }
        }
        public string? Perfil { get; set; }
        public string? Status { get; set; }
        public DateTime? UltimoLogin { get; set; }
        public DateTime CreatedAt { get; set; }

        public Usuario()
        {
            IdUsuario = 0;
            Status = "ativo";
            CreatedAt = DateTime.Now;
        }

        public Usuario(int idUsuario)
        {
            IdUsuario = idUsuario;
        }

        public Usuario(string? email, string? senha)
        {
            Email = email;
            SenhaHash = senha;
        }

        public Usuario(int idUsuario, string? nome, string? email, string? senhaHash, string? perfil, string? status, DateTime? ultimoLogin, DateTime createdAt)
        {
            IdUsuario = idUsuario;
            Nome = nome;
            Email = email;
            SenhaHash = senhaHash;
            Perfil = perfil;
            Status = status;
            UltimoLogin = ultimoLogin;
            CreatedAt = createdAt;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into usuarios (nome, email, senha_hash, perfil, status, ultimo_login)
                    values (@nome, @email, @senha_hash, @perfil, @status, @ultimo_login);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@senha_hash", SenhaHash);
                cmd.Parameters.AddWithValue("@perfil", Perfil);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativo" : Status);
                cmd.Parameters.AddWithValue("@ultimo_login", UltimoLogin.HasValue ? UltimoLogin.Value : DBNull.Value);

                IdUsuario = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdUsuario > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdUsuario < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update usuarios
                    set nome = @nome,
                        email = @email,
                        senha_hash = @senha_hash,
                        perfil = @perfil,
                        status = @status,
                        ultimo_login = @ultimo_login
                    where id_usuario = @id_usuario";

                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@nome", Nome);
                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@senha_hash", SenhaHash);
                cmd.Parameters.AddWithValue("@perfil", Perfil);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativo" : Status);
                cmd.Parameters.AddWithValue("@ultimo_login", UltimoLogin.HasValue ? UltimoLogin.Value : DBNull.Value);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdUsuario < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from usuarios where id_usuario = @id_usuario";
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Usuario ObterPorId(int idUsuario)
        {
            Usuario usuario = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_usuario, nome, email, senha_hash, perfil, status, ultimo_login, created_at
                    from usuarios
                    where id_usuario = @id_usuario";
                cmd.Parameters.AddWithValue("@id_usuario", idUsuario);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    usuario = MontarUsuario(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return usuario;
        }

        public static List<Usuario> ObterLista(string busca = "")
        {
            List<Usuario> usuarios = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_usuario, nome, email, senha_hash, perfil, status, ultimo_login, created_at
                    from usuarios
                    where nome like @busca or email like @busca or perfil like @busca
                    order by nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    usuarios.Add(MontarUsuario(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return usuarios;
        }

        public List<Usuario> ObterListar()
        {
            return ObterLista();
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from usuarios order by nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public bool Autenticar()
        {
            bool autenticado = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_usuario, nome, email, senha_hash, perfil, status, ultimo_login, created_at
                    from usuarios
                    where email = @email and senha_hash = @senha_hash and status = 'ativo'";

                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@senha_hash", SenhaHash);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Usuario usuario = MontarUsuario(dr);
                    IdUsuario = usuario.IdUsuario;
                    Nome = usuario.Nome;
                    Email = usuario.Email;
                    SenhaHash = usuario.SenhaHash;
                    Perfil = usuario.Perfil;
                    Status = usuario.Status;
                    UltimoLogin = usuario.UltimoLogin;
                    CreatedAt = usuario.CreatedAt;
                    autenticado = true;
                }

                dr.Close();
                cmd.Connection.Close();
            }

            if (autenticado)
                RegistrarUltimoLogin();

            return autenticado;
        }

        public bool AlterarSenha()
        {
            bool alterado = false;
            if (IdUsuario < 1) return alterado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update usuarios set senha_hash = @senha_hash where id_usuario = @id_usuario";
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@senha_hash", SenhaHash);

                if (cmd.ExecuteNonQuery() > 0)
                    alterado = true;

                cmd.Connection.Close();
            }

            return alterado;
        }

        private bool RegistrarUltimoLogin()
        {
            bool registrado = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update usuarios set ultimo_login = now() where id_usuario = @id_usuario";
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);

                if (cmd.ExecuteNonQuery() > 0)
                    registrado = true;

                cmd.Connection.Close();
            }

            return registrado;
        }

        private static Usuario MontarUsuario(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetString(1),
                dr.GetString(2),
                dr.GetString(3),
                dr.GetString(4),
                dr.GetString(5),
                dr.IsDBNull(6) ? null : dr.GetDateTime(6),
                dr.GetDateTime(7)
            );
        }
    }
}
