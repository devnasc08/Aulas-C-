using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Professor
    {
        public int IdProfessor { get; set; }
        public int IdUsuario { get; set; }
        public string? Cpf { get; set; }
        public string? Especialidade { get; set; }
        public Usuario? Usuario { get; set; }

        public Professor()
        {
            IdProfessor = 0;
        }

        public Professor(int idProfessor)
        {
            IdProfessor = idProfessor;
        }

        public Professor(int idProfessor, int idUsuario, string? cpf, string? especialidade)
        {
            IdProfessor = idProfessor;
            IdUsuario = idUsuario;
            Cpf = cpf;
            Especialidade = especialidade;
        }

        public Professor(int idUsuario, string? cpf, string? especialidade)
        {
            IdUsuario = idUsuario;
            Cpf = cpf;
            Especialidade = especialidade;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into professores (id_usuario, cpf, especialidade)
                    values (@id_usuario, @cpf, @especialidade);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@cpf", Cpf);
                cmd.Parameters.AddWithValue("@especialidade", string.IsNullOrEmpty(Especialidade) ? DBNull.Value : Especialidade);

                IdProfessor = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdProfessor > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdProfessor < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update professores
                    set id_usuario = @id_usuario,
                        cpf = @cpf,
                        especialidade = @especialidade
                    where id_professor = @id_professor";

                cmd.Parameters.AddWithValue("@id_professor", IdProfessor);
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@cpf", Cpf);
                cmd.Parameters.AddWithValue("@especialidade", string.IsNullOrEmpty(Especialidade) ? DBNull.Value : Especialidade);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdProfessor < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from professores where id_professor = @id_professor";
                cmd.Parameters.AddWithValue("@id_professor", IdProfessor);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Professor ObterPorId(int idProfessor)
        {
            Professor professor = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_professor, id_usuario, cpf, especialidade
                    from professores
                    where id_professor = @id_professor";
                cmd.Parameters.AddWithValue("@id_professor", idProfessor);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    professor = MontarProfessor(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return professor;
        }

        public static List<Professor> ObterLista(string busca = "")
        {
            List<Professor> professores = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select p.id_professor, p.id_usuario, p.cpf, p.especialidade
                    from professores p
                    inner join usuarios u on u.id_usuario = p.id_usuario
                    where u.nome like @busca or p.cpf like @busca or p.especialidade like @busca
                    order by u.nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    professores.Add(MontarProfessor(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return professores;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select p.*, u.nome, u.email
                    from professores p
                    inner join usuarios u on u.id_usuario = p.id_usuario
                    order by u.nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        private static Professor MontarProfessor(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetString(2),
                dr.IsDBNull(3) ? null : dr.GetString(3)
            );
        }
    }
}
