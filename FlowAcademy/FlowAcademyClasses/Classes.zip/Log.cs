using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Log
    {
        public int IdLog { get; set; }
        public int IdUsuario { get; set; }
        public string? Acao { get; set; }
        public string? Ip { get; set; }
        public DateTime DataEvento { get; set; }
        public Usuario? Usuario { get; set; }

        public Log()
        {
            IdLog = 0;
            DataEvento = DateTime.Now;
        }

        public Log(int idLog)
        {
            IdLog = idLog;
        }

        public Log(int idLog, int idUsuario, string? acao, string? ip, DateTime dataEvento)
        {
            IdLog = idLog;
            IdUsuario = idUsuario;
            Acao = acao;
            Ip = ip;
            DataEvento = dataEvento;
        }

        public Log(int idUsuario, string? acao, string? ip)
        {
            IdUsuario = idUsuario;
            Acao = acao;
            Ip = ip;
            DataEvento = DateTime.Now;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into logs (id_usuario, acao, ip)
                    values (@id_usuario, @acao, @ip);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@acao", Acao);
                cmd.Parameters.AddWithValue("@ip", string.IsNullOrEmpty(Ip) ? DBNull.Value : Ip);

                IdLog = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdLog > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdLog < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update logs
                    set id_usuario = @id_usuario,
                        acao = @acao,
                        ip = @ip,
                        data_evento = @data_evento
                    where id_log = @id_log";

                cmd.Parameters.AddWithValue("@id_log", IdLog);
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@acao", Acao);
                cmd.Parameters.AddWithValue("@ip", string.IsNullOrEmpty(Ip) ? DBNull.Value : Ip);
                cmd.Parameters.AddWithValue("@data_evento", DataEvento == DateTime.MinValue ? DateTime.Now : DataEvento);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdLog < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from logs where id_log = @id_log";
                cmd.Parameters.AddWithValue("@id_log", IdLog);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Log ObterPorId(int idLog)
        {
            Log log = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_log, id_usuario, acao, ip, data_evento
                    from logs
                    where id_log = @id_log";
                cmd.Parameters.AddWithValue("@id_log", idLog);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    log = MontarLog(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return log;
        }

        public static List<Log> ObterLista(string busca = "")
        {
            List<Log> logs = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select l.id_log, l.id_usuario, l.acao, l.ip, l.data_evento
                    from logs l
                    inner join usuarios u on u.id_usuario = l.id_usuario
                    where l.acao like @busca or l.ip like @busca or u.nome like @busca
                    order by l.data_evento desc";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    logs.Add(MontarLog(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return logs;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select l.*, u.nome as usuario
                    from logs l
                    inner join usuarios u on u.id_usuario = l.id_usuario
                    order by l.data_evento desc";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public static bool Registrar(int idUsuario, string? acao, string? ip = null)
        {
            Log log = new(idUsuario, acao, ip);
            return log.Inserir();
        }

        private static Log MontarLog(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetString(2),
                dr.IsDBNull(3) ? null : dr.GetString(3),
                dr.GetDateTime(4)
            );
        }
    }
}
