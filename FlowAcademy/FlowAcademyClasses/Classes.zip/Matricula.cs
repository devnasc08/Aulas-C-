using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Matricula
    {
        public int IdMatricula { get; set; }
        public int IdAluno { get; set; }
        public int IdTurma { get; set; }
        public DateTime DataMatricula { get; set; }
        public string? Status { get; set; }
        public Aluno? Aluno { get; set; }
        public Turma? Turma { get; set; }

        public Matricula()
        {
            IdMatricula = 0;
            DataMatricula = DateTime.Today;
            Status = "ativa";
        }

        public Matricula(int idMatricula)
        {
            IdMatricula = idMatricula;
        }

        public Matricula(int idMatricula, int idAluno, int idTurma, DateTime dataMatricula, string? status)
        {
            IdMatricula = idMatricula;
            IdAluno = idAluno;
            IdTurma = idTurma;
            DataMatricula = dataMatricula;
            Status = status;
        }

        public Matricula(int idAluno, int idTurma, DateTime dataMatricula, string? status)
        {
            IdAluno = idAluno;
            IdTurma = idTurma;
            DataMatricula = dataMatricula;
            Status = status;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into matriculas (id_aluno, id_turma, data_matricula, status)
                    values (@id_aluno, @id_turma, @data_matricula, @status);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_aluno", IdAluno);
                cmd.Parameters.AddWithValue("@id_turma", IdTurma);
                cmd.Parameters.AddWithValue("@data_matricula", DataMatricula == DateTime.MinValue ? DateTime.Today : DataMatricula.Date);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativa" : Status);

                IdMatricula = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdMatricula > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdMatricula < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update matriculas
                    set id_aluno = @id_aluno,
                        id_turma = @id_turma,
                        data_matricula = @data_matricula,
                        status = @status
                    where id_matricula = @id_matricula";

                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);
                cmd.Parameters.AddWithValue("@id_aluno", IdAluno);
                cmd.Parameters.AddWithValue("@id_turma", IdTurma);
                cmd.Parameters.AddWithValue("@data_matricula", DataMatricula == DateTime.MinValue ? DateTime.Today : DataMatricula.Date);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativa" : Status);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdMatricula < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from matriculas where id_matricula = @id_matricula";
                cmd.Parameters.AddWithValue("@id_matricula", IdMatricula);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Matricula ObterPorId(int idMatricula)
        {
            Matricula matricula = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_matricula, id_aluno, id_turma, data_matricula, status
                    from matriculas
                    where id_matricula = @id_matricula";
                cmd.Parameters.AddWithValue("@id_matricula", idMatricula);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    matricula = MontarMatricula(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return matricula;
        }

        public static List<Matricula> ObterLista(string busca = "")
        {
            List<Matricula> matriculas = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select m.id_matricula, m.id_aluno, m.id_turma, m.data_matricula, m.status
                    from matriculas m
                    inner join alunos a on a.id_aluno = m.id_aluno
                    inner join usuarios u on u.id_usuario = a.id_usuario
                    inner join turmas t on t.id_turma = m.id_turma
                    where u.nome like @busca or a.matricula like @busca or t.codigo_turma like @busca
                    order by m.data_matricula desc";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    matriculas.Add(MontarMatricula(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return matriculas;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select m.*, u.nome as aluno, t.codigo_turma
                    from matriculas m
                    inner join alunos a on a.id_aluno = m.id_aluno
                    inner join usuarios u on u.id_usuario = a.id_usuario
                    inner join turmas t on t.id_turma = m.id_turma
                    order by m.data_matricula desc";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public bool RealizarMatricula()
        {
            if (!new Turma(IdTurma).PossuiVaga())
                return false;

            DataMatricula = DateTime.Today;
            Status = "ativa";
            return Inserir();
        }

        private static Matricula MontarMatricula(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetInt32(2),
                dr.GetDateTime(3),
                dr.GetString(4)
            );
        }
    }
}
