using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Turma
    {
        public int IdTurma { get; set; }
        public int IdCurso { get; set; }
        public int IdProfessor { get; set; }
        public string? CodigoTurma { get; set; }
        public string? Turno { get; set; }
        public string? PeriodoLetivo { get; set; }
        public int CapacidadeMaxima { get; set; }
        public string? Status { get; set; }
        public Curso? Curso { get; set; }
        public Professor? Professor { get; set; }

        public Turma()
        {
            IdTurma = 0;
            CapacidadeMaxima = 35;
            Status = "ativa";
        }

        public Turma(int idTurma)
        {
            IdTurma = idTurma;
        }

        public Turma(int idTurma, int idCurso, int idProfessor, string? codigoTurma, string? turno, string? periodoLetivo, int capacidadeMaxima, string? status)
        {
            IdTurma = idTurma;
            IdCurso = idCurso;
            IdProfessor = idProfessor;
            CodigoTurma = codigoTurma;
            Turno = turno;
            PeriodoLetivo = periodoLetivo;
            CapacidadeMaxima = capacidadeMaxima;
            Status = status;
        }

        public Turma(int idCurso, int idProfessor, string? codigoTurma, string? turno, string? periodoLetivo, int capacidadeMaxima, string? status)
        {
            IdCurso = idCurso;
            IdProfessor = idProfessor;
            CodigoTurma = codigoTurma;
            Turno = turno;
            PeriodoLetivo = periodoLetivo;
            CapacidadeMaxima = capacidadeMaxima;
            Status = status;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into turmas (id_curso, id_professor, codigo_turma, turno, periodo_letivo, capacidade_maxima, status)
                    values (@id_curso, @id_professor, @codigo_turma, @turno, @periodo_letivo, @capacidade_maxima, @status);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_curso", IdCurso);
                cmd.Parameters.AddWithValue("@id_professor", IdProfessor);
                cmd.Parameters.AddWithValue("@codigo_turma", CodigoTurma);
                cmd.Parameters.AddWithValue("@turno", Turno);
                cmd.Parameters.AddWithValue("@periodo_letivo", PeriodoLetivo);
                cmd.Parameters.AddWithValue("@capacidade_maxima", CapacidadeMaxima < 1 ? 35 : CapacidadeMaxima);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativa" : Status);

                IdTurma = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdTurma > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdTurma < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update turmas
                    set id_curso = @id_curso,
                        id_professor = @id_professor,
                        codigo_turma = @codigo_turma,
                        turno = @turno,
                        periodo_letivo = @periodo_letivo,
                        capacidade_maxima = @capacidade_maxima,
                        status = @status
                    where id_turma = @id_turma";

                cmd.Parameters.AddWithValue("@id_turma", IdTurma);
                cmd.Parameters.AddWithValue("@id_curso", IdCurso);
                cmd.Parameters.AddWithValue("@id_professor", IdProfessor);
                cmd.Parameters.AddWithValue("@codigo_turma", CodigoTurma);
                cmd.Parameters.AddWithValue("@turno", Turno);
                cmd.Parameters.AddWithValue("@periodo_letivo", PeriodoLetivo);
                cmd.Parameters.AddWithValue("@capacidade_maxima", CapacidadeMaxima < 1 ? 35 : CapacidadeMaxima);
                cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(Status) ? "ativa" : Status);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdTurma < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from turmas where id_turma = @id_turma";
                cmd.Parameters.AddWithValue("@id_turma", IdTurma);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Turma ObterPorId(int idTurma)
        {
            Turma turma = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_turma, id_curso, id_professor, codigo_turma, turno, periodo_letivo, capacidade_maxima, status
                    from turmas
                    where id_turma = @id_turma";
                cmd.Parameters.AddWithValue("@id_turma", idTurma);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    turma = MontarTurma(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return turma;
        }

        public static List<Turma> ObterLista(string busca = "")
        {
            List<Turma> turmas = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select t.id_turma, t.id_curso, t.id_professor, t.codigo_turma, t.turno, t.periodo_letivo, t.capacidade_maxima, t.status
                    from turmas t
                    inner join cursos c on c.id_curso = t.id_curso
                    where t.codigo_turma like @busca or t.periodo_letivo like @busca or c.nome like @busca
                    order by t.periodo_letivo, t.codigo_turma";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    turmas.Add(MontarTurma(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return turmas;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select t.*, c.nome as curso, u.nome as professor
                    from turmas t
                    inner join cursos c on c.id_curso = t.id_curso
                    inner join professores p on p.id_professor = t.id_professor
                    inner join usuarios u on u.id_usuario = p.id_usuario
                    order by t.periodo_letivo, t.codigo_turma";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public bool PossuiVaga()
        {
            bool possuiVaga = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select capacidade_maxima > (
                        select count(*) from matriculas
                        where id_turma = @id_turma and status = 'ativa'
                    )
                    from turmas
                    where id_turma = @id_turma";
                cmd.Parameters.AddWithValue("@id_turma", IdTurma);

                object? resultado = cmd.ExecuteScalar();
                if (resultado != null && resultado != DBNull.Value)
                    possuiVaga = Convert.ToBoolean(resultado);

                cmd.Connection.Close();
            }

            return possuiVaga;
        }

        private static Turma MontarTurma(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetInt32(2),
                dr.GetString(3),
                dr.GetString(4),
                dr.GetString(5),
                dr.GetInt32(6),
                dr.GetString(7)
            );
        }
    }
}
