using System;
using System.Collections.Generic;
using System.Data;

namespace FlowAcademyClasses
{
    public class Aluno
    {
        public int IdAluno { get; set; }
        public int IdUsuario { get; set; }
        public string? Matricula { get; set; }
        public string? Cpf { get; set; }
        public string? Telefone { get; set; }
        public DateTime? DataNascimento { get; set; }
        public string? Endereco { get; set; }
        public string? StatusAcademico { get; set; }
        public Usuario? Usuario { get; set; }

        public Aluno()
        {
            IdAluno = 0;
            StatusAcademico = "regular";
        }

        public Aluno(int idAluno)
        {
            IdAluno = idAluno;
        }

        public Aluno(int idAluno, int idUsuario, string? matricula, string? cpf, string? telefone, DateTime? dataNascimento, string? endereco, string? statusAcademico)
        {
            IdAluno = idAluno;
            IdUsuario = idUsuario;
            Matricula = matricula;
            Cpf = cpf;
            Telefone = telefone;
            DataNascimento = dataNascimento;
            Endereco = endereco;
            StatusAcademico = statusAcademico;
        }

        public Aluno(int idUsuario, string? matricula, string? cpf, string? telefone, DateTime? dataNascimento, string? endereco, string? statusAcademico)
        {
            IdUsuario = idUsuario;
            Matricula = matricula;
            Cpf = cpf;
            Telefone = telefone;
            DataNascimento = dataNascimento;
            Endereco = endereco;
            StatusAcademico = statusAcademico;
        }

        public bool Inserir()
        {
            bool inserido = false;
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"insert into alunos (id_usuario, matricula, cpf, telefone, data_nascimento, endereco, status_academico)
                    values (@id_usuario, @matricula, @cpf, @telefone, @data_nascimento, @endereco, @status_academico);
                    select last_insert_id();";

                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@matricula", Matricula);
                cmd.Parameters.AddWithValue("@cpf", Cpf);
                cmd.Parameters.AddWithValue("@telefone", string.IsNullOrEmpty(Telefone) ? DBNull.Value : Telefone);
                cmd.Parameters.AddWithValue("@data_nascimento", DataNascimento.HasValue ? DataNascimento.Value.Date : DBNull.Value);
                cmd.Parameters.AddWithValue("@endereco", string.IsNullOrEmpty(Endereco) ? DBNull.Value : Endereco);
                cmd.Parameters.AddWithValue("@status_academico", string.IsNullOrEmpty(StatusAcademico) ? "regular" : StatusAcademico);

                IdAluno = Convert.ToInt32(cmd.ExecuteScalar());
                inserido = IdAluno > 0;
                cmd.Connection.Close();
            }

            return inserido;
        }

        public bool Atualizar()
        {
            bool atualizado = false;
            if (IdAluno < 1) return atualizado;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"update alunos
                    set id_usuario = @id_usuario,
                        matricula = @matricula,
                        cpf = @cpf,
                        telefone = @telefone,
                        data_nascimento = @data_nascimento,
                        endereco = @endereco,
                        status_academico = @status_academico
                    where id_aluno = @id_aluno";

                cmd.Parameters.AddWithValue("@id_aluno", IdAluno);
                cmd.Parameters.AddWithValue("@id_usuario", IdUsuario);
                cmd.Parameters.AddWithValue("@matricula", Matricula);
                cmd.Parameters.AddWithValue("@cpf", Cpf);
                cmd.Parameters.AddWithValue("@telefone", string.IsNullOrEmpty(Telefone) ? DBNull.Value : Telefone);
                cmd.Parameters.AddWithValue("@data_nascimento", DataNascimento.HasValue ? DataNascimento.Value.Date : DBNull.Value);
                cmd.Parameters.AddWithValue("@endereco", string.IsNullOrEmpty(Endereco) ? DBNull.Value : Endereco);
                cmd.Parameters.AddWithValue("@status_academico", string.IsNullOrEmpty(StatusAcademico) ? "regular" : StatusAcademico);

                if (cmd.ExecuteNonQuery() > 0)
                    atualizado = true;

                cmd.Connection.Close();
            }

            return atualizado;
        }

        public bool Alterar()
        {
            return Atualizar();
        }

        public bool Excluir()
        {
            bool excluido = false;
            if (IdAluno < 1) return excluido;

            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from alunos where id_aluno = @id_aluno";
                cmd.Parameters.AddWithValue("@id_aluno", IdAluno);

                if (cmd.ExecuteNonQuery() > 0)
                    excluido = true;

                cmd.Connection.Close();
            }

            return excluido;
        }

        public static Aluno ObterPorId(int idAluno)
        {
            Aluno aluno = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select id_aluno, id_usuario, matricula, cpf, telefone, data_nascimento, endereco, status_academico
                    from alunos
                    where id_aluno = @id_aluno";
                cmd.Parameters.AddWithValue("@id_aluno", idAluno);

                var dr = cmd.ExecuteReader();
                if (dr.Read())
                    aluno = MontarAluno(dr);

                dr.Close();
                cmd.Connection.Close();
            }

            return aluno;
        }

        public static List<Aluno> ObterLista(string busca = "")
        {
            List<Aluno> alunos = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select a.id_aluno, a.id_usuario, a.matricula, a.cpf, a.telefone, a.data_nascimento, a.endereco, a.status_academico
                    from alunos a
                    inner join usuarios u on u.id_usuario = a.id_usuario
                    where u.nome like @busca or a.matricula like @busca or a.cpf like @busca
                    order by u.nome";
                cmd.Parameters.AddWithValue("@busca", $"%{busca}%");

                var dr = cmd.ExecuteReader();
                while (dr.Read())
                    alunos.Add(MontarAluno(dr));

                dr.Close();
                cmd.Connection.Close();
            }

            return alunos;
        }

        public static DataTable Listar()
        {
            DataTable tabela = new();
            var cmd = Banco.Abrir();
            if (cmd.Connection.State == ConnectionState.Open)
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = @"select a.*, u.nome, u.email
                    from alunos a
                    inner join usuarios u on u.id_usuario = a.id_usuario
                    order by u.nome";
                tabela.Load(cmd.ExecuteReader());
                cmd.Connection.Close();
            }

            return tabela;
        }

        public bool Cadastrar()
        {
            if (IdUsuario < 1) return false;
            if (string.IsNullOrEmpty(Matricula)) return false;
            if (string.IsNullOrEmpty(Cpf)) return false;

            return Inserir();
        }

        private static Aluno MontarAluno(IDataRecord dr)
        {
            return new(
                dr.GetInt32(0),
                dr.GetInt32(1),
                dr.GetString(2),
                dr.GetString(3),
                dr.IsDBNull(4) ? null : dr.GetString(4),
                dr.IsDBNull(5) ? null : dr.GetDateTime(5),
                dr.IsDBNull(6) ? null : dr.GetString(6),
                dr.GetString(7)
            );
        }
    }
}
